# -*- coding: utf-8 -*-
"""
Example with SyntaxError
========================

Sphinx-Gallery uses Python's AST parser, thus you need to have written
valid python code for Sphinx-Gallery to parse it. If your script has a
SyntaxError you'll be presented the traceback and the original code.
"""
# Code source: Óscar Nájera
# License: BSD 3 clause

Invalid Python code
